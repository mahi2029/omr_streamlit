import cv2
import numpy as np
import os
import random

# Output directories
os.makedirs("dataset/filled", exist_ok=True)
os.makedirs("dataset/empty", exist_ok=True)

# Parameters
num_samples = 500          # images per class
img_size = 28              # 28x28 pixels

def add_noise(img):
    """Add random noise to image to simulate real sheets"""
    noise = np.random.randint(0, 30, (img_size, img_size), dtype='uint8')
    img = cv2.add(img, noise)
    return img

for i in range(num_samples):
    # Empty bubble
    empty = np.ones((img_size, img_size), dtype='uint8') * 255
    cv2.circle(empty, (img_size//2, img_size//2), img_size//2 - 2, (0,0,0), 1)
    empty = add_noise(empty)
    cv2.imwrite(f"dataset/empty/empty_{i}.jpg", empty)

    # Filled bubble
    filled = np.ones((img_size, img_size), dtype='uint8') * 255
    cv2.circle(filled, (img_size//2, img_size//2), img_size//2 - 2, (0,0,0), -1)
    filled = add_noise(filled)
    cv2.imwrite(f"dataset/filled/filled_{i}.jpg", filled)

print("✅ Synthetic bubble dataset generated!")